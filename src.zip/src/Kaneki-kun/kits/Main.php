<?php
namespace Kaneki-kun\kits;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\Player;


class Main extends PluginBase{


   public function onEnable(){
        $this->reloadConfig();

    }


    public function onLoad(){
        $this->saveDefaultConfig();
    }


    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
        switch($cmd->getName()){
            case "default":
            break;
        }
     return false;
    }
}